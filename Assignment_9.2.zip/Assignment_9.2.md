

```python
import numpy as np
```


```python
x=np.arange(0,100)
y=x*2
z=x**2
```


```python
import matplotlib.pyplot as plt
%matplotlib inline
```

Create a figure object called fig using plt.figure() 
Use add_axes to add an axis to the figure canvas at [0,0,1,1]. Call this new axis ax. 
Plot (x,y) on that axes and set the labels and titles to match the plot below:


```python

fig = plt.figure()

ax = fig.add_axes([0,0,1,1])
ax.set_title('title')
ax.set_xlabel('x')
ax.set_ylabel('y')

ax.plot(x,y)
```




    [<matplotlib.lines.Line2D at 0x28f14208ba8>]




![png](output_4_1.png)


Create a figure object and put two axes on it, ax1 and ax2. Located at [0,0,1,1] and [0.2,0.5,.2,.2] respectively.


```python
fig1 = plt.figure()

ax1 = fig1.add_axes([0,0,1,1])
ax2 = fig1.add_axes([0.2,0.5,.2,.2])
```


![png](output_6_0.png)


Now plot (x,y) on both axes. And call your figure object to show it


```python
fig1 = plt.figure()

ax1 = fig1.add_axes([0,0,1,1])
ax2 = fig1.add_axes([0.2,0.5,.2,.2])

ax1.plot(x,y)
ax2.plot(x,y)
```




    [<matplotlib.lines.Line2D at 0x28f1604a358>]




![png](output_8_1.png)


Create the plot below by adding two axes to a figure object at [0,0,1,1] and [0.2,0.5,.4,.4]


```python
fig1 = plt.figure()
ax0 = fig1.add_axes([0,0,1,1])
ax1 = fig1.add_axes([0.2,0.5,.4,.4])

ax0.set_xlabel('X')
ax0.set_ylabel('Z')

ax1.set_xlabel('X')
ax1.set_ylabel('Z')
ax1.set_ylim(30,50)
ax1.set_xlim(20,22)

ax0.plot(x,z)
ax1.plot(x,y)
```




    [<matplotlib.lines.Line2D at 0x28f160e8ef0>]




![png](output_10_1.png)



Now use x,y, and z arrays to recreate the plot below. Notice the xlimits and y limits on the inserted plot:



```python
fig1 = plt.figure()

ax3 = fig1.add_axes([0,0,1,1])
ax4 = fig1.add_axes([0.2,0.5,.4,.4])
```


![png](output_12_0.png)


Use plt.subplots(nrows=1, ncols=2) to create the plot below.


```python

fig,axes = plt.subplots(nrows=1,ncols=2)
```


![png](output_14_0.png)



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
